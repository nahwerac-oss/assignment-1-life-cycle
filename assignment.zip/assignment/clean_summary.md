|       |   Rank |     Score |   Overall_Score_Normalized |
|:------|-------:|----------:|---------------------------:|
| count |      0 | 10000     |                  10000     |
| mean  |    nan |    71.676 |                      0.205 |
| std   |    nan |    89.211 |                      0.259 |
| min   |    nan |     1     |                      0     |
| max   |    nan |   346     |                      1     |